
let button=document.getElementById('up-button')
window.addEventListener('scroll',function(){
if(this.document.documentElement.scrollTop>300)
{
    button.style.display='block'
}
else{
    button.style.display='none'
}

})


// let smhhhhh=document.getElementById('hjsdjhdkdjkhds')
// window.addEventListener('scroll',function(){
// if(this.document.documentElement.scrollTop>300)
// {
//     button.style.display='block'
// }
// else{
//     button.style.display='none'
// }

// })